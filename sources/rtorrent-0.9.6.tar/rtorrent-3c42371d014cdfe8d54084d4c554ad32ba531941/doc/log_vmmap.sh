#!/bin/bash
vmmap -interleaved $PPID > $1
